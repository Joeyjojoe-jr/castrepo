# ChatGPT Codex Playbook
Rules: open Issues, then PRs with code+tests+docs. No network in tests. Respect contracts. Keep commits small.
Tasks to start:
1) Switch Next API to import compiled packages after publishing.
2) Add flow editor UI page for composing DAGs.
3) Add Codecov upload step (optional).