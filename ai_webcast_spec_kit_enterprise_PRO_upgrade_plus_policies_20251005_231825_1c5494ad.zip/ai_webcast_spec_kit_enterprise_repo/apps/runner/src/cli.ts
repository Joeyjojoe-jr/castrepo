#!/usr/bin/env node
import { runFlow, simpleNewsFlow } from '../../packages/flows/src/index.js';
import FeedFetcher from '../../packages/agents/feedfetcher/src/index.js';
import Dedupe from '../../packages/agents/dedupe/src/index.js';
import Exporter from '../../packages/agents/exporter/src/index.js';

const registry = { FeedFetcher, Dedupe, Exporter };
runFlow(simpleNewsFlow(), registry).then(state=>{
  const out = state['export'];
  console.log(out?.body ?? JSON.stringify(state,null,2));
});
