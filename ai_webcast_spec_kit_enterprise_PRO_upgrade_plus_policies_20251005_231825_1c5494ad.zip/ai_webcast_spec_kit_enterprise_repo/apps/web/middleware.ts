import { NextResponse } from 'next/server';
export function middleware(req: Request) {
  const res = NextResponse.next();
  res.headers.set('X-Content-Type-Options', 'nosniff');
  res.headers.set('X-Frame-Options', 'DENY');
  res.headers.set('Referrer-Policy', 'no-referrer');
  res.headers.set('Strict-Transport-Security', 'max-age=15552000; includeSubDomains');
  res.headers.set('Content-Security-Policy', "default-src 'self'; frame-ancestors 'none'");
  const cid = req.headers.get('x-corr-id') ?? (globalThis.crypto?.randomUUID?.() ?? 'cid-' + Math.random().toString(36).slice(2));
  res.headers.set('x-corr-id', cid);
  return res;
}
