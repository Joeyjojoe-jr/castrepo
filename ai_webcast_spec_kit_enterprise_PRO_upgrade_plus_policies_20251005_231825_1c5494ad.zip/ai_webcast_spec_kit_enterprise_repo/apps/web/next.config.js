module.exports = { experimental: { typedRoutes: true } };
