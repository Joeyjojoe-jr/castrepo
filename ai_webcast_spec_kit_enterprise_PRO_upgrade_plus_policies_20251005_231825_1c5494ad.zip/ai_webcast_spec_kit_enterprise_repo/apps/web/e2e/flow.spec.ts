import { test, expect } from '@playwright/test';
test('runs demo flow', async ({ page }) => {
  await page.goto('/');
  await page.getByRole('button', { name: /Run demo/i }).click();
  await expect(page.getByText(/flow completed/i)).toBeVisible();
});
