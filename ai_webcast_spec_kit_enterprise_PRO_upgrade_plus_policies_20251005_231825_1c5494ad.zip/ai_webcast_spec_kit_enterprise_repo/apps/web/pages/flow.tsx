import { useEffect, useState } from 'react';

const defaultFlow = {
  nodes: {
    fetch: { agent: 'FeedFetcher', input: { source: 'fixtures' } },
    dedupe: { agent: 'Dedupe' },
    export: { agent: 'Exporter', input: { format: 'md' } }
  },
  edges: [
    { from: 'fetch', to: 'dedupe' },
    { from: 'dedupe', to: 'export' }
  ]
};

export default function FlowEditor(){
  const [jsonText,setJsonText] = useState(JSON.stringify(defaultFlow,null,2));
  const [out,setOut] = useState('');
  const [flows,setFlows] = useState<string[]>([]);
  const [name,setName] = useState('my_flow');

  async function refreshList(){
    const r = await fetch('/api/flows/list'); const j = await r.json(); setFlows(j.flows||[]);
  }
  useEffect(()=>{ refreshList(); }, []);

  async function runIt(){
    const r = await fetch('/api/flow', { method:'POST', headers:{'Content-Type':'application/json'}, body: jsonText });
    const t = await r.text(); setOut(t);
  }
  async function saveIt(){
    const r = await fetch('/api/flows/save', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ name, flow: JSON.parse(jsonText) }) });
    if(r.ok){ await refreshList(); }
  }
  async function loadIt(n:string){
    const r = await fetch('/api/flows/load?name='+encodeURIComponent(n)); const j = await r.json();
    if(j.flow){ setJsonText(JSON.stringify(j.flow,null,2)); setName(n.replace(/\.json$/,'')); }
  }

  // Minimal param helpers
  function setNodeInput(nodeKey:string, input:any){
    try{
      const obj = JSON.parse(jsonText);
      obj.nodes[nodeKey] = obj.nodes[nodeKey] || { agent: 'FeedFetcher' };
      obj.nodes[nodeKey].input = input;
      setJsonText(JSON.stringify(obj,null,2));
    } catch {}
  }

  return (<main style={{padding:20}}>
    <h1>Flow Editor</h1>
    <section style={{display:'flex', gap:16}}>
      <div style={{flex:1}}>
        <h3>Flow JSON</h3>
        <textarea style={{width:'100%',height:300}} value={jsonText} onChange={e=>setJsonText(e.target.value)} />
        <div style={{marginTop:8, display:'flex', gap:8}}>
          <button onClick={runIt}>Run</button>
          <input value={name} onChange={e=>setName(e.target.value)} placeholder="name"/>
          <button onClick={saveIt}>Save</button>
        </div>
        <div style={{marginTop:8}}>
          <strong>Saved flows:</strong>
          <ul>
            {flows.map(n=> <li key={n}><a href="#" onClick={(e)=>{e.preventDefault(); loadIt(n);}}>{n}</a></li>)}
          </ul>
        </div>
      </div>
      <div style={{flex:1}}>
        <h3>Parameter helpers</h3>
        <div>
          <button onClick={()=>setNodeInput('fetch',{ source:'fixtures' })}>Set fetch.input = fixtures</button>
        </div>
        <div style={{marginTop:8}}>
          <button onClick={()=>setNodeInput('export',{ format:'md' })}>Set export.format = md</button>
          <button onClick={()=>setNodeInput('export',{ format:'json' })} style={{marginLeft:8}}>Set export.format = json</button>
        </div>
      </div>
    </section>
    <h3>Output</h3>
    <pre>{out}</pre>
  </main>);
}
