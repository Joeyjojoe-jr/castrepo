import type { NextApiRequest, NextApiResponse } from 'next';
import { runFlow } from '../../../packages/flows/src/index';
import { FlowSchema } from '../../../packages/flows/src/schema';
import FeedFetcher from '../../../packages/agents/feedfetcher/src';
import Dedupe from '../../../packages/agents/dedupe/src';
import Exporter from '../../../packages/agents/exporter/src';

export default async function handler(req:NextApiRequest,res:NextApiResponse){
  try{
    const parsed = FlowSchema.parse(req.body);
    const registry = { FeedFetcher, Dedupe, Exporter };
    const state = await runFlow(parsed as any, registry);
    const out = (state as any)['export']?.body ?? JSON.stringify(state,null,2);
    res.setHeader('Content-Type','text/markdown');
    res.status(200).send(out);
  } catch(err:any){
    res.status(400).json({ error: err?.message || 'Invalid flow' });
  }
}
