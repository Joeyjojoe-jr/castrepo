import type { NextApiRequest, NextApiResponse } from 'next';
import fs from 'node:fs';
import path from 'node:path';

export default async function handler(req:NextApiRequest,res:NextApiResponse){
  const dir = path.join(process.cwd(), 'flows');
  try {
    const files = fs.readdirSync(dir).filter(f=>f.endsWith('.json'));
    res.status(200).json({ flows: files });
  } catch {
    res.status(200).json({ flows: [] });
  }
}
