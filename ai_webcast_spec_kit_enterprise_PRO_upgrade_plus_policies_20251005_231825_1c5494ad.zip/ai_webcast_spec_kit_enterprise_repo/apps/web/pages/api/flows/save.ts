import type { NextApiRequest, NextApiResponse } from 'next';
import fs from 'node:fs';
import path from 'node:path';
import { FlowSchema } from '../../../../packages/flows/src/schema';

export const config = { api: { bodyParser: { sizeLimit: '1mb' } } };

export default async function handler(req:NextApiRequest,res:NextApiResponse){
  if(req.method!=='POST') return res.status(405).end();
  try{
    const { name, flow } = req.body || {};
    const safe = String(name||'').replace(/[^a-zA-Z0-9_\-]/g,'');
    if(!safe) return res.status(400).json({ error: 'name required' });
    const parsed = FlowSchema.parse(flow);
    const dir = path.join(process.cwd(), 'flows');
    if(!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, safe + '.json');
    fs.writeFileSync(file, JSON.stringify(parsed,null,2));
    res.status(200).json({ ok:true, name: safe });
  }catch(err:any){
    res.status(400).json({ error: err?.message || 'invalid' });
  }
}
