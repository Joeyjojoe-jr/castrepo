import type { NextApiRequest, NextApiResponse } from 'next';
import fs from 'node:fs';
import path from 'node:path';

export default async function handler(req:NextApiRequest,res:NextApiResponse){
  const name = String(req.query.name||'').replace(/[^a-zA-Z0-9_\-]/g,'');
  if(!name) return res.status(400).json({ error: 'name required' });
  const file = path.join(process.cwd(), 'flows', name.endsWith('.json')? name : name + '.json');
  if(!fs.existsSync(file)) return res.status(404).json({ error: 'not found' });
  const data = fs.readFileSync(file,'utf-8');
  res.status(200).json({ name, flow: JSON.parse(data) });
}
