export default function handler(_req:any, res:any){
  res.setHeader('content-type','application/json; charset=utf-8');
  res.status(200).json({ ok:true, ts:new Date().toISOString(), version: process.env.npm_package_version });
}
