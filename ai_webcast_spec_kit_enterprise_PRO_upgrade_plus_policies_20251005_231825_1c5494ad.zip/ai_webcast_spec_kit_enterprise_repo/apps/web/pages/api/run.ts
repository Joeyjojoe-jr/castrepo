import type { NextApiRequest, NextApiResponse } from 'next';
import { runFlow, simpleNewsFlow } from '../../../packages/flows/src/index';
import FeedFetcher from '../../../packages/agents/feedfetcher/src';
import Dedupe from '../../../packages/agents/dedupe/src';
import Exporter from '../../../packages/agents/exporter/src';

export default async function handler(req:NextApiRequest,res:NextApiResponse){
  const registry = { FeedFetcher, Dedupe, Exporter };
  const state = await runFlow(simpleNewsFlow(), registry);
  const out = (state as any)['export'];
  res.setHeader('Content-Type','text/markdown');
  res.status(200).send(out.body);
}
