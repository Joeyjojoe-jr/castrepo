import { useState } from 'react';
export default function Home(){const [out,setOut]=useState<string>('');return (<main style={{padding:20}}><h1>Spec-Kit Workbench</h1><button onClick={async()=>{const r=await fetch('/api/run',{method:'POST'});const t=await r.text();setOut(t)}}>Run demo</button><pre>{out}</pre></main>)}
