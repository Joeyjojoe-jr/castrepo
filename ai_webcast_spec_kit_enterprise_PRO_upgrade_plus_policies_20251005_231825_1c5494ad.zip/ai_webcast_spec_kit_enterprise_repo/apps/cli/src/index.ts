console.log('spec-cli');
