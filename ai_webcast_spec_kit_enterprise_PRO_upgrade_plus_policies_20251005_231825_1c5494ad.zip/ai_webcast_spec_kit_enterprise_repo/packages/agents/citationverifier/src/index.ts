import type { AgentContract } from '@spec/contracts';
function isHttps(url?: string): boolean { try { const u = new URL(String(url)); return u.protocol==='https:' && !!u.host; } catch { return false; } }
export const CitationVerifier: AgentContract<{citations:any[]; claims:string},{ok:boolean;issues:string[]}> = {
  name: 'CitationVerifier',
  async run(input){
    const issues: string[] = [];
    if (!Array.isArray(input?.citations)) issues.push('citations not array');
    if (!input?.claims) issues.push('claims missing');
    for (const c of (input.citations || [])) { if (!isHttps(c?.url)) issues.push(`non-https or invalid url: ${c?.url}`); }
    if (process.env.LIVE_VERIFY==='1'){ const slice=(input.citations||[]).slice(0,5); for(const c of slice){ try{ const res=await fetch(c.url,{method:'HEAD'}); if(!res.ok) issues.push(`url not reachable (${res.status}): ${c.url}`); } catch { issues.push(`url fetch error: ${c.url}`); } } }
    return { ok: issues.length===0, issues };
  }
};
export default CitationVerifier;
