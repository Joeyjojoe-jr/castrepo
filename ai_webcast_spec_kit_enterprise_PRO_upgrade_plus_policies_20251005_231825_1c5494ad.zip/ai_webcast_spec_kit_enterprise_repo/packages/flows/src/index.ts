import type { Flow } from './schema';


export type Registry = Record<string, { run: (input:any)=>Promise<any> }>;
export async function runFlow(flow: Flow, registry: Registry) {
  const state: Record<string,any> = {};
  const executed = new Set<string>();
  const maxIters = Object.keys(flow.nodes).length * 3;
  for (let i=0; i<maxIters; i++) {
    for (const [id, ref] of Object.entries(flow.nodes)) {
      if (executed.has(id)) continue;
      const preds = flow.edges.filter(e=>e.to===id).map(e=>e.from);
      if (preds.some(p=>!executed.has(p))) continue;
      let input = ref.input;
      if (!input && preds.length === 1) input = state[preds[0]];
      const agent = registry[ref.agent];
      if (!agent) throw new Error(`agent not found: ${ref.agent}`);
      const out = await agent.run(input ?? {});
      state[id] = out;
      executed.add(id);
    }
    if (executed.size === Object.keys(flow.nodes).length) break;
  }
  return state;
}
export function simpleNewsFlow(){ return {
  nodes:{ fetch:{agent:'FeedFetcher',input:{source:'fixtures'}}, dedupe:{agent:'Dedupe'}, export:{agent:'Exporter',input:{format:'md'}} },
  edges:[ {from:'fetch',to:'dedupe'}, {from:'dedupe',to:'export'} ]
} as Flow;}
