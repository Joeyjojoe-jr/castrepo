import { z } from 'zod';
export const NodeRef = z.object({
  agent: z.string(),
  input: z.any().optional()
});
export const Edge = z.object({
  from: z.string(),
  to: z.string()
});
export const FlowSchema = z.object({
  nodes: z.record(NodeRef),
  edges: z.array(Edge)
});
export type Flow = z.infer<typeof FlowSchema>;
