type Level = 'debug'|'info'|'warn'|'error';
const levelOrder: Record<Level, number> = { debug:10, info:20, warn:30, error:40 };
const envLevel = (process.env.LOG_LEVEL as Level) ?? 'info';

export function logger(ctx?: { corrId?: string; runId?: string }) {
  const base = { corrId: ctx?.corrId, runId: ctx?.runId };
  function log(level: Level, msg: string, meta?: unknown) {
    if (levelOrder[level] < levelOrder[envLevel]) return;
    // eslint-disable-next-line no-console
    console[level === 'debug' ? 'log' : level](
      JSON.stringify({ level, ts: new Date().toISOString(), ...base, msg, meta })
    );
  }
  return { debug:(m:string,x?:unknown)=>log('debug',m,x),
           info:(m:string,x?:unknown)=>log('info',m,x),
           warn:(m:string,x?:unknown)=>log('warn',m,x),
           error:(m:string,x?:unknown)=>log('error',m,x) };
}
