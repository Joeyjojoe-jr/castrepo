import { jitteredBackoff } from './backoff';
import { logger } from './logger';
import { getResult, seen, setResult } from './idempotency';

export type StepFn<I,O> = (input: I, ctx: { corrId: string; runId: string; signal: AbortSignal }) => Promise<O>;

export async function runFlow<I,O>(opts: {
  name: string; steps: { name: string; fn: StepFn<any,any> }[];
  input: I; retries?: number; timeoutMs?: number; corrId?: string; idempotencyKey?: string;
}): Promise<O> {
  const corrId = opts.corrId ?? (globalThis.crypto?.randomUUID?.() ?? 'cid-' + Math.random().toString(36).slice(2));
  const runId = globalThis.crypto?.randomUUID?.() ?? 'rid-' + Math.random().toString(36).slice(2);
  const log = logger({ corrId, runId });
  const key = opts.idempotencyKey ? `${opts.name}:${opts.idempotencyKey}` : undefined;
  if (key && seen(key)) { log.info('idempotent hit'); return getResult<O>(key)!; }
  log.info('flow.started', { name: opts.name });

  let current: any = opts.input;
  for (const [idx, step] of opts.steps.entries()) {
    const attemptMax = (opts.retries ?? 2) + 1;
    let attempt = 0;
    for (;;) {
      attempt++;
      const ac = new AbortController();
      const to = setTimeout(() => ac.abort(), opts.timeoutMs ?? 120_000);
      try {
        log.info('step.started', { step: step.name, attempt });
        current = await step.fn(current, { corrId, runId, signal: ac.signal });
        clearTimeout(to);
        log.info('step.succeeded', { step: step.name, idx });
        break;
      } catch (e: any) {
        clearTimeout(to);
        if (attempt >= attemptMax) {
          log.error('step.failed', { step: step.name, error: String(e?.message ?? e) });
          throw e;
        }
        const wait = jitteredBackoff(attempt);
        log.warn('step.retry', { step: step.name, attempt, wait });
        await new Promise(r => setTimeout(r, wait));
      }
    }
  }
  if (key) setResult<O>(key, current);
  log.info('flow.succeeded', { name: opts.name });
  return current as O;
}
