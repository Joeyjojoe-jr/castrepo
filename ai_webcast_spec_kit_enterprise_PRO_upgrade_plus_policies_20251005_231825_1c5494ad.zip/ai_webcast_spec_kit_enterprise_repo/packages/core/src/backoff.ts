export function jitteredBackoff(attempt: number, baseMs = 200, capMs = 5000) {
  const exp = Math.min(capMs, baseMs * 2 ** attempt);
  const jitter = Math.floor(Math.random() * (exp / 2));
  return exp - jitter;
}
