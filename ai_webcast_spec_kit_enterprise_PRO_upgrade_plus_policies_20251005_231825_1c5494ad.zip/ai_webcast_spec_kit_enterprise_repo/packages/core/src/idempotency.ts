const store = new Map<string, unknown>();
export function seen(key: string): boolean { return store.has(key); }
export function setResult<T>(key: string, value: T) { store.set(key, value); }
export function getResult<T>(key: string): T | undefined { return store.get(key) as T | undefined; }
