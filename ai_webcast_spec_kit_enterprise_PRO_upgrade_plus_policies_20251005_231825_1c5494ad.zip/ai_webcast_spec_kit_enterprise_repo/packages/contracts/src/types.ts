import { z } from 'zod';
export const Citation = z.object({ title:z.string().optional(), url:z.string().url() });
export type Citation = z.infer<typeof Citation>;
export const Item = z.object({ id:z.string(), title:z.string(), url:z.string().url(), content:z.string().optional() });
export type Item = z.infer<typeof Item>;
export const FeedFetchInput = z.object({ source:z.enum(['fixtures']) });
export const FeedFetchOutput = z.object({ items: z.array(Item) });
