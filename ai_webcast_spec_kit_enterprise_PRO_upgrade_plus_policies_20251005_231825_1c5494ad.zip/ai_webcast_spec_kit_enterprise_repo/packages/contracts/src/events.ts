export type EventType =
  | 'flow.started' | 'step.started' | 'step.succeeded' | 'step.failed'
  | 'flow.succeeded' | 'flow.failed';

export interface Event<T = unknown> {
  type: EventType;
  ts: string;
  corrId: string;
  runId: string;
  payload: T;
}

export interface AgentContract<I, O> {
  name: string;
  run: (input: I, ctx: { corrId: string; runId: string; signal: AbortSignal }) => Promise<O>;
}
