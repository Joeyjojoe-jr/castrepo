import { z } from 'zod';

export const CorrelationId = z.string().uuid();
export const IdempotencyKey = z.string().min(8);

export const Citation = z.object({
  title: z.string().optional(),
  url: z.string().url(),
});
export type Citation = z.infer<typeof Citation>;

export const Item = z.object({
  id: z.string(),
  title: z.string(),
  url: z.string().url(),
  content: z.string().optional(),
  citations: z.array(Citation).default([]),
});
export type Item = z.infer<typeof Item>;

export const FeedFetchInput = z.object({ source: z.enum(['fixtures']) });
export const FeedFetchOutput = z.object({ items: z.array(Item) });

export const DedupeInput = FeedFetchOutput;
export const DedupeOutput = z.object({ items: z.array(Item) });

export const VerifyInput = DedupeOutput;
export const VerifyOutput = z.object({
  items: z.array(Item),
  verified: z.boolean(),
});

export const ExportInput = VerifyOutput;
export const ExportOutput = z.object({
  path: z.string(),
  count: z.number().int().nonnegative(),
});

export const StepName = z.enum(['feed-fetch', 'dedupe', 'verify', 'export']);
export const StepResult = z.object({
  step: StepName,
  startedAt: z.string(),
  endedAt: z.string(),
  success: z.boolean(),
  error: z.string().optional(),
});

export const FlowSpec = z.object({
  name: z.string(),
  version: z.string(),
  steps: z.array(StepName),
  timeoutMs: z.number().int().positive().default(120_000),
  retries: z.number().int().min(0).max(5).default(2),
});
export type FlowSpec = z.infer<typeof FlowSpec>;
