#!/usr/bin/env bash
set -euo pipefail

: "${ORG:?Set ORG=<your org or user>}"
: "${REPO:?Set REPO=<your repo name>}"

# Enable key security features
gh api -X PATCH repos/$ORG/$REPO   --raw-field "security_and_analysis[secret_scanning][status]=enabled"   --raw-field "security_and_analysis[secret_scanning_push_protection][status]=enabled"   --raw-field "security_and_analysis[dependabot_alerts][status]=enabled"

gh api -X PUT repos/$ORG/$REPO/automated-security-fixes -f "enabled=true" >/dev/null || true
gh api -X PUT repos/$ORG/$REPO/vulnerability-alerts >/dev/null || true

# Require PRs, code owners, and CI checks on main
gh api --method PUT repos/$ORG/$REPO/branches/main/protection   -H "Accept: application/vnd.github+json"   -F required_status_checks.strict=true   -F required_status_checks.contexts[]="ci / build-test (20)"   -F required_status_checks.contexts[]="ci / build-test (22)"   -F enforce_admins=true   -F required_pull_request_reviews.dismiss_stale_reviews=true   -F required_pull_request_reviews.require_code_owner_reviews=true   -F required_pull_request_reviews.required_approving_review_count=1   -F restrictions='null'

# Merge strategy: squash only, delete branches on merge
gh api -X PATCH repos/$ORG/$REPO   -f allow_squash_merge=true   -f allow_merge_commit=false   -f allow_rebase_merge=false   -f delete_branch_on_merge=true

# Default branch
gh api -X PATCH repos/$ORG/$REPO -f default_branch=main

echo "Policy applied to $ORG/$REPO"
