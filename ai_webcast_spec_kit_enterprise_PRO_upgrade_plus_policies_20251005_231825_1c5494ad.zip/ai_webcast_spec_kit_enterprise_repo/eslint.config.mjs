// root eslint.config.mjs
import js from "@eslint/js";
import ts from "typescript-eslint";
import pluginImport from "eslint-plugin-import";

export default ts.config(
  js.configs.recommended,
  ...ts.configs.recommendedTypeChecked,
  {
    files: ["**/*.ts", "**/*.tsx"],
    languageOptions: {
      parserOptions: { project: ["tsconfig.base.json"], tsconfigRootDir: import.meta.dirname },
    },
    plugins: { import: pluginImport },
    rules: {
      "no-console": ["error", { allow: ["warn", "error"] }],
      "@typescript-eslint/consistent-type-imports": "error",
      "@typescript-eslint/no-explicit-any": "error",
      "import/order": ["error", {
        "newlines-between": "always",
        "alphabetize": { "order": "asc" },
        "groups": [["builtin","external"],["internal"],["parent","sibling","index"]]
      }],
    },
    ignores: ["dist", "coverage", ".next"],
  }
);
