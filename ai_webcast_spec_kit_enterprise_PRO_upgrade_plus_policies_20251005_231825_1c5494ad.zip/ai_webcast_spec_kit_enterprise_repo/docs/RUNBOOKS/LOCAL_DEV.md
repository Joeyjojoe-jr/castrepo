# Local Dev
1) corepack enable && pnpm i
2) pnpm -r build
3) pnpm --filter @spec/web dev
