# Full Setup Guide

This guide covers setup for **spec-kit_plus_persist_publish**.

## 0) Prereqs
- Node 20.11+ and Git.
- pnpm via Corepack.
- Docker (optional).

```bash
corepack enable
corepack prepare pnpm@9.6.0 --activate
node -v
pnpm -v
```

## 1) Get the code
```bash
unzip <zipfile>.zip
cd <unzipped-folder>
cp .env.example .env
```

## 2) Install and build
```bash
pnpm i
pnpm -r build
```

## 3) Run tests
```bash
pnpm test
```

## 4) Start the web workbench
```bash
pnpm --filter @spec/web dev
# open http://localhost:3000 and http://localhost:3000/flow
```

## 5) Flow editor + persistence
- Edit JSON on `/flow`.
- **Run** executes server-side.
- **Save** persists to `./flows/<name>.json`.
- APIs: `/api/flows/list`, `/api/flows/load?name=...`, `/api/flows/save`.

## 6) CLI demo
```bash
pnpm --filter @spec/runner build
node apps/runner/dist/cli.js
```

## 7) Docker
Dev:
```bash
docker compose up --build
```
Prod-like:
```bash
docker compose -f compose.prod.yml up --build
```

## 8) GitHub setup
```bash
git init && git add . && git commit -m "init: spec-kit"
git branch -M main
git remote add origin <your-repo-url>
git push -u origin main
```
Actions:
- `ci.yml` runs install, build, tests, coverage check.
- `codex.yml` labels/guards PRs.
- `release.yml` publishes a selected package (manual dispatch).

Secrets:
- `CODECOV_TOKEN` for coverage uploads (optional).
- `NPM_TOKEN` for package publishing.

## 9) Agent packages
Internal packages under `packages/agents/*`:
- `@spec/agent-dedupe`
- `@spec/agent-feedfetcher`
- `@spec/agent-exporter`
- `@spec/agent-citationverifier`

Local publish:
```bash
pnpm -r build
npm login
pnpm --filter @spec/agent-dedupe publish --access public
```

GitHub publish:
- Run **Actions → publish** with `package=@spec/agent-dedupe`.
- Requires `NPM_TOKEN`.

## 10) Flows orchestrator
- Library: `packages/flows` (`runFlow`, `FlowSchema`).
- Demo: `simpleNewsFlow()` used by web API and CLI.

## 11) Optional live URL verification
- Set `LIVE_VERIFY=1` to enable HEAD probes in `CitationVerifier`.
- Keep `LIVE_VERIFY=0` for CI and normal dev.

## 12) Fixtures policy
- No network in tests.
- Refresh `fixtures/feed/sample.json` manually. See `scripts/snapshot-fixtures.md`.

## 13) ChatGPT Codex workflow
- Read `CHATGPT_CODEX_PLAYBOOK.md`.
- Open Issue using the **Codex Task** template.
- In ChatGPT, paste the playbook system prompt and give the Issue URL.
- ChatGPT proposes a PR. You review and merge.

## 14) Troubleshooting
- Port 3000 in use → `PORT=3001 pnpm --filter @spec/web dev`
- Wrong Node → install v20.x and run Corepack
- pnpm missing → run Corepack commands
- CI coverage fails → `pnpm test` locally and commit missing tests
