# Overview

This repo implements a minimal agent pipeline for AI webcasts:
- **FeedFetcher**: returns items from fixtures
- **Dedupe**: removes duplicate URLs
- **CitationVerifier**: validates citation URL shape (optionally live-checks via `LIVE_VERIFY=1`)
- **Exporter**: outputs Markdown or JSON

Everything is wired through a tiny flows orchestrator (`@spec/flows`) and exposed via a web workbench and CLI.
