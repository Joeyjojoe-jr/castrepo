# Docs Index

- [Overview](./OVERVIEW.md)
- [Architecture](./ARCHITECTURE.md)
- [SWOT](./SWOT.md)
- [Setup](./SETUP_GUIDE.md)
