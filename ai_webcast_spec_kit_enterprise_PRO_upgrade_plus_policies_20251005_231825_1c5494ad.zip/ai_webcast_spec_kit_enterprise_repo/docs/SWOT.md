# SWOT

## Strengths
- Clear monorepo structure and typed contracts.
- Deterministic fixtures for tests, coverage gate.
- Web workbench + CLI + flows orchestrator.
- Docker dev/prod and CI ready.

## Weaknesses
- Minimal verifier logic by design (no content semantics).
- Next imports local sources; publishing to a registry would improve consumption.
- No auth, RBAC, or persistence beyond JSON files.

## Opportunities
- Add semantic checks (title/host match) and pluggable policies.
- Graph storage (Neo4j) and richer DAG UI.
- Package and version agents for reuse across repos.

## Threats
- Live network checks can be flaky; must stay optional.
- Monorepo growth without strict governance could add coupling.
- Security hardening needed for public deployments.
