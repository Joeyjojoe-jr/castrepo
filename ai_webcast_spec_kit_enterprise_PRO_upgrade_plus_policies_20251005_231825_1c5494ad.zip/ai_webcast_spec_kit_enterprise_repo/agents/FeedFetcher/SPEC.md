# FeedFetcher
Return items from deterministic fixtures for tests and demos.
