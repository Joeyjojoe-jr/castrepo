import { describe, it, expect } from 'vitest';
import { FeedFetcher } from './impl';
describe('FeedFetcher',()=>{ it('returns items from fixtures', async ()=>{ const r = await FeedFetcher.run({ source:'fixtures' }); expect(Array.isArray(r.items)).toBe(true); expect(r.items.length).toBeGreaterThan(0); }); });
