import type { AgentContract } from '@spec/contracts';
import type { Item } from '@spec/contracts';
export const FeedFetcher: AgentContract<{source:'fixtures'},{items:Item[]}>={name:'FeedFetcher',async run(i){if(i.source!=='fixtures')return{items:[]};const data = await import('../../fixtures/feed/sample.json',{ assert:{ type:'json' } } as any).catch(()=>({default:[]}));return{items:(data as any).default as Item[]}}};
