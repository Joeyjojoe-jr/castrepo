# Exporter
Emit JSON or Markdown from items.
Contract: `export({items, format}) -> { mime, body }`.
