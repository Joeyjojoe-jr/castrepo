import type { AgentContract } from '@spec/contracts';
import type { Item } from '@spec/contracts';
export const Exporter: AgentContract<{items:Item[],format:'json'|'md'},{mime:string,body:string}>={name:'Exporter',async run(i){if(i.format==='json'){return{mime:'application/json',body:JSON.stringify(i.items,null,2)}}const lines=['# Export',''];for(const it of i.items){lines.push(`- [${it.title}](${it.url})`)}return{mime:'text/markdown',body:lines.join('\n')}}};
