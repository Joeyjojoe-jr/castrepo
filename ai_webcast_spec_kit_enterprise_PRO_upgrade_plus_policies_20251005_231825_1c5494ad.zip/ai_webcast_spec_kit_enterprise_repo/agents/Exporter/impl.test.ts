import { describe, it, expect } from 'vitest';
import { Exporter } from './impl';
const items = [ {id:'1',title:'A',url:'https://a.com'},{id:'2',title:'B',url:'https://b.com'} ] as any;
describe('Exporter',()=>{ it('json', async ()=>{ const r=await Exporter.run({items,format:'json'}); expect(r.mime).toBe('application/json'); expect(JSON.parse(r.body).length).toBe(2); }); it('md', async ()=>{ const r=await Exporter.run({items,format:'md'}); expect(r.mime).toBe('text/markdown'); expect(r.body.includes('[A](https://a.com)')).toBe(true); }); });
