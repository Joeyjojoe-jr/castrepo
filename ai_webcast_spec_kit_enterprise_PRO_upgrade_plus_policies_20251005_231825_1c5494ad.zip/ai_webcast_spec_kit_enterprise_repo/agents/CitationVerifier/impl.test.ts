import { describe,it,expect } from 'vitest';
import { CitationVerifier } from './impl';
describe('CitationVerifier',()=>{ it('rejects non-array', async ()=>{ const r=await CitationVerifier.run({citations:'x' as any,claims:''}); expect(r.ok).toBe(false); }); it('flags http', async ()=>{ const r=await CitationVerifier.run({citations:[{url:'http://x.com'}],claims:'c'}); expect(r.ok).toBe(false); }); it('accepts https', async ()=>{ const r=await CitationVerifier.run({citations:[{url:'https://x.com'}],claims:'c'}); expect(r.ok).toBe(true); }); });
