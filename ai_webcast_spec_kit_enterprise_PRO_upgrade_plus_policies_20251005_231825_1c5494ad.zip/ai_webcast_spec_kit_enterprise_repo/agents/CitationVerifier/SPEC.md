# CitationVerifier
Verify citation URLs against claims. Flag non-HTTPS or invalid URLs. Optional live checks behind `LIVE_VERIFY=1`.
