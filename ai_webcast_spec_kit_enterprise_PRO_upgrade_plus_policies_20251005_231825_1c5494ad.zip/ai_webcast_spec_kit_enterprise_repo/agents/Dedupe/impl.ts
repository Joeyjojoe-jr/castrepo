import type { AgentContract } from '@spec/contracts';
import type { Item } from '@spec/contracts';
export const Dedupe: AgentContract<{items:Item[]},{items:Item[]}>={name:'Dedupe',async run(i){const seen=new Set<string>();const out:Item[]=[];(i.items||[]).forEach(it=>{const k=(it.url||'').replace(/\/?$/,'/').toLowerCase();if(!seen.has(k)){seen.add(k);out.push(it)}});return{items:out}}};
