# Dedupe
Drop duplicates by normalized URL/title.
Contract: `dedupe(items: Item[]) -> Item[]`.
