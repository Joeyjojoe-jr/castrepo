import { describe,it,expect } from 'vitest';
import { Dedupe } from './impl';
describe('Dedupe',()=>{ it('removes url dupes', async ()=>{ const a:any={id:'1',title:'t',url:'https://x.com'}; const b:any={id:'2',title:'t2',url:'https://x.com/'}; const r=await Dedupe.run({items:[a,b]}); expect(r.items.length).toBe(1); }); });
